num = input("请输入正整数:")
a=num[::-1]
if a==num:
    print(f"{num}是回文数")
else:
    print(f"{num}不是回文数")