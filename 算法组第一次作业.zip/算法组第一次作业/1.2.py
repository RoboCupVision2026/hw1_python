a=input("please input a number:")
a=int(a)
b=input("please input another number:")
b=int(b)
c=input("please input another number:")
c=int(c)
list=[a,b,c]
list.sort()
print(list)
