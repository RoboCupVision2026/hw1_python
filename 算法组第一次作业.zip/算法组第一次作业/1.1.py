list=[]
i=0
for a in range(1,5):
    for b in range(1, 5):
        for c in range(1, 5):
            if a==b or a==c or b==c:
                continue
            else:
                num = a + b * 10 + c * 100
                if num not in list:
                    i+=1
                    list.append(num)
print(f"一共有{i}个三位数,分别是{list}")