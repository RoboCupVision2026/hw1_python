a = input("请输入任意整数:")
l = len(a)
print(f"这个整数是{l}位数")
print(a[::-1])