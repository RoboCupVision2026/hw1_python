p = list(range(1,234))
while len(p)>1:
    a = len(p)//3
    if a==0:
        break
    p=p[3*a:]+[p[3*i+j] for i in range(a) for j in (0,1)]
print(p)
