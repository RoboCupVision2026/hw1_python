l=list(range(100))
for idx in range(99,0,-1):
    if l[idx]%2==1:
        l.pop(idx)
print(l)