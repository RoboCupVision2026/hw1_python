class Person:
    def __init__(self, name, age, gender):
        self.name, self.age, self.gender = name, age, gender

    def personInfo(self):
        print(f"姓名:{self.name}, 年龄:{self.age}, 性别:{self.gender}")
class Student(Person):
    def __init__(self, name, age, gender, college, cls):
        super().__init__(name, age, gender)
        self.college, self.cls = college, cls
    def personInfo(self):
        super().personInfo()
        print(f"学院:{self.college}, 班级:{self.cls}")
    def __str__(self):
        return f"Student({self.name},{self.age},{self.gender},{self.college},{self.cls})"
s = Student("张三", 20, "男", "计算机学院", "1班")
s.personInfo()
print(s)