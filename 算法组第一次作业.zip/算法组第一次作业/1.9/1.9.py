from pathlib import Path
import random
img_path = Path("img")
img_path.mkdir(exist_ok=True)
for i in range(1, 101):
    (img_path / f"{i}.png").touch()
files = list(Path("img").glob("*"))
for f in random.sample(files, 50):
    f.rename(f.with_suffix(".jpg"))