import random, statistics

data = [[random.randint(1, 100) for _ in range(3)] for _ in range(10)]
with open('data.csv', 'w') as f:
    for row in data:
        f.write(','.join(map(str, row)) + '\n')

col2 = [row[1] for row in data]
print(f"最大值: {max(col2)}")
print(f"最小值: {min(col2)}")
print(f"平均值: {sum(col2)/len(col2)}")
print(f"中位数: {statistics.median(col2)}")