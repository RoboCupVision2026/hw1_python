import random
from pathlib import Path
files = list(Path("img").glob("*"))
for f in random.sample(files, 50):
    f.rename(f.with_suffix(".jpg"))