import random, os
i, j = int(input("文件数 i：")), int(input("每文件行数 j："))
os.makedirs("test", exist_ok=True)
for n in range(1, i + 1):
    path = os.path.join("test", f"file{n}.txt")
    with open(path, "w") as f:
        for _ in range(j):
            f.write("".join(chr(random.randint(32, 126)) for _ in range(20)) + "\n")
for name in os.listdir("test"):
    path = os.path.join("test", name)
    with open(path, "r") as f:
        lines = f.readlines()
    with open(path, "w") as f:
        f.write(name + "-python\n")
        for line in lines:
            f.write(line.rstrip("\n") + "-python\n")