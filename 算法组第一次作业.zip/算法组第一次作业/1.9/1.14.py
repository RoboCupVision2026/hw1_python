with open("test.txt") as a, open("copy_test.txt") as b:
    la, lb = a.readlines(), b.readlines()
for i, (x, y) in enumerate(zip(la, lb), 1):
    if x != y:
        print(i)
if len(la) != len(lb):
    for i in range(min(len(la), len(lb)) + 1, max(len(la), len(lb)) + 1):
        print(i)