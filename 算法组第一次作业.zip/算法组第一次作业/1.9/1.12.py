import random, shutil

i = int(input("请输入行数 i："))
with open("test.txt", "w") as f:
    for _ in range(i):
        line = "".join(chr(random.randint(32, 126)) for _ in range(20))
        f.write(line + "\n")
shutil.copy("test.txt", "copy_test.txt")
with open("test.txt", "r") as f:
    content = f.read()
with open("test.txt", "w") as f:
    f.write("python\n" + content + "\npython")