list=[0,1]
for i in range(1,19):
    list.append(list[-1]+list[-2])
print(list)